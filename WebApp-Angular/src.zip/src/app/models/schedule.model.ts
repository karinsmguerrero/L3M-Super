export class Schedule {
    Name:string;
    Week:string;
    Hours:number;
    Officce:string;
}
