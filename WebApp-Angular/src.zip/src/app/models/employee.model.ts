export class Employee {
    Name:string;
    Id:string;
    Birth:string;
    Hiring:string;
    Branch:string;
    Salary:string;

}
