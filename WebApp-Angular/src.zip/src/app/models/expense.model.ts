export class Expense {
    Date:string;
    Provider:string;
    Description:string;
    Price:number;

}
