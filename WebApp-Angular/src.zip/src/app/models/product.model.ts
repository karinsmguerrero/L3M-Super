export class Product {
    Name:string;
    Description:string;
    Code:number;
    Provider:string;
    Price:number;
    Tax:number;
    Discount:number;
    Quantity:number;
}
