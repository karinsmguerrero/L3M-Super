import { Schedule } from './schedule.model';

describe('Schedule', () => {
  it('should create an instance', () => {
    expect(new Schedule()).toBeTruthy();
  });
});
