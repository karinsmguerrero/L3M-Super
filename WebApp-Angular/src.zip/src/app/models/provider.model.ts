export class Provider {
    Name:string;
    ID:number;
}
