import { Provider } from './provider.model';

describe('Provider', () => {
  it('should create an instance', () => {
    expect(new Provider()).toBeTruthy();
  });
});
