import { Expense } from './expense.model';

describe('Expense', () => {
  it('should create an instance', () => {
    expect(new Expense()).toBeTruthy();
  });
});
