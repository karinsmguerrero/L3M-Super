export class Officce {
    Name:string;
    Address:string;
    Telephone:string;
    Administrator:string;
}
