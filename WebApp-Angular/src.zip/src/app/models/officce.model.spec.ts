import { Officce } from './officce.model';

describe('Officce', () => {
  it('should create an instance', () => {
    expect(new Officce()).toBeTruthy();
  });
});
