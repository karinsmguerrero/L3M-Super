export class Purchase {
    Description:string;
    PurchaseDate:string;
    RegistrationDate:string;
    Provider:string;
    Branch:string;
}
