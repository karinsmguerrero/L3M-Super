import { Purchase } from './purchase.model';

describe('Purchase', () => {
  it('should create an instance', () => {
    expect(new Purchase()).toBeTruthy();
  });
});
