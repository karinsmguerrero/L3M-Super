export class Role {
    Name:string;
    Description:string;
}
