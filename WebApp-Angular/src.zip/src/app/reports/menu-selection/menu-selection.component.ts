import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-selection',
  templateUrl: './menu-selection.component.html',
  styleUrls: ['./menu-selection.component.css']
})
export class MenuSelectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
